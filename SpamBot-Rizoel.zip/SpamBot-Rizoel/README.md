<p align="center">
  <img src="./resources/logo.jpg" alt="BOT-SPAM Logo">
</p>
<h1 align="center">
  <b>ʀɪᴢᴏᴇʟ X sᴘᴀᴍ</b>
</h1>

[![Forks](https://img.shields.io/github/forks/MrRizoel/Spambot?style=flat-square&color=orange)](https://github.com/MrRizoel/Spambot/fork)
[![Python](https://img.shields.io/badge/Python-v3.9.7-blue)](https://www.python.org/)
[![Open Source Love svg2](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/MrRizoel/Spambot)   
----
 
- [x] ☯︎ ғᴀsᴛ ᴀɴᴅ sᴛᴀʙʟᴇ ☯︎
- [x] Deploy 10 Bots in One time 🔥
- [x] Deploy Using Bot Token 

# Deploy on heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/royal2011/spambot-heroku)


# Support & Updates
* [Channel](https://t.me/RiZoeLX)
* [Support Group](https://t.me/DNHcHELL)

# Credits
* [RiZoeL Creator](https://github.com/MrRizoel)
* [Lonami](https://github.com/LonamiWebs/) for [Telethon.](https://github.com/LonamiWebs/Telethon)
